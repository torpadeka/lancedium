import { Link } from "react-router-dom"
import { Star } from "lucide-react"
import { Card, CardContent, CardFooter } from "./ui/Card"
import type { Service } from "../types"

interface ServiceCardProps {
  service: Service
}

const ServiceCard = ({ service }: ServiceCardProps) => {
  return (
    <Link to={`/freelancer/${service.freelancerId}`} className="block">
      <Card className="h-full overflow-hidden service-card-hover">
        <div className="aspect-video w-full overflow-hidden">
          <img
            src={service.image || `/placeholder.svg?height=200&width=300`}
            alt={service.title}
            className="h-full w-full object-cover transition-transform duration-300"
          />
        </div>
        <CardContent className="p-4">
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-medium truncate">{service.title}</h3>
            <div className="flex items-center">
              <Star className="h-4 w-4 fill-current text-yellow-500" />
              <span className="ml-1 text-sm">{service.rating.toFixed(1)}</span>
            </div>
          </div>
          <p className="text-sm text-gray-600 dark:text-gray-400 line-clamp-2">{service.description}</p>
        </CardContent>
        <CardFooter className="p-4 pt-0 flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <div className="h-6 w-6 rounded-full overflow-hidden">
              <img
                src={service.freelancerAvatar || `/placeholder.svg?height=24&width=24`}
                alt={service.freelancerName}
                className="h-full w-full object-cover"
              />
            </div>
            <span className="text-sm">{service.freelancerName}</span>
          </div>
          <div className="font-medium">${service.price}</div>
        </CardFooter>
      </Card>
    </Link>
  )
}

export default ServiceCard
