"use client"

import { useState } from "react"
import { Link, useLocation } from "react-router-dom"
import { Menu, X, Sun, Moon } from "lucide-react"
import { Button } from "./ui/Button"
import { useTheme } from "./ThemeProvider"
import { useAuth } from "../contexts/AuthContext"

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false)
  const { theme, setTheme } = useTheme()
  const { user, logout } = useAuth()
  const location = useLocation()

  const toggleMenu = () => setIsOpen(!isOpen)
  const closeMenu = () => setIsOpen(false)

  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark")
  }

  const isActive = (path: string) => {
    return location.pathname === path
  }

  return (
    <nav className="border-b border-gray-200 dark:border-gray-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex-shrink-0 flex items-center" onClick={closeMenu}>
              <span className="text-xl font-bold">FreelanceHub</span>
            </Link>
            <div className="hidden sm:ml-6 sm:flex sm:space-x-8">
              <Link
                to="/"
                className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium ${
                  isActive("/")
                    ? "border-gray-900 dark:border-gray-100"
                    : "border-transparent hover:border-gray-300 dark:hover:border-gray-700"
                }`}
                onClick={closeMenu}
              >
                Home
              </Link>
              <Link
                to="/browse"
                className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium ${
                  isActive("/browse")
                    ? "border-gray-900 dark:border-gray-100"
                    : "border-transparent hover:border-gray-300 dark:hover:border-gray-700"
                }`}
                onClick={closeMenu}
              >
                Browse Services
              </Link>
              {user && (
                <Link
                  to="/dashboard"
                  className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium ${
                    isActive("/dashboard")
                      ? "border-gray-900 dark:border-gray-100"
                      : "border-transparent hover:border-gray-300 dark:hover:border-gray-700"
                  }`}
                  onClick={closeMenu}
                >
                  Dashboard
                </Link>
              )}
            </div>
          </div>
          <div className="hidden sm:ml-6 sm:flex sm:items-center sm:space-x-4">
            <Button variant="ghost" size="icon" onClick={toggleTheme} aria-label="Toggle theme">
              {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </Button>
            {user ? (
              <>
                <Button variant="outline" onClick={logout}>
                  Sign Out
                </Button>
              </>
            ) : (
              <>
                <Link to="/login" onClick={closeMenu}>
                  <Button variant="outline">Sign In</Button>
                </Link>
                <Link to="/register" onClick={closeMenu}>
                  <Button>Sign Up</Button>
                </Link>
              </>
            )}
          </div>
          <div className="flex items-center sm:hidden">
            <Button variant="ghost" size="icon" onClick={toggleTheme} className="mr-2" aria-label="Toggle theme">
              {theme === "dark" ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </Button>
            <Button variant="ghost" size="icon" onClick={toggleMenu} aria-label="Open menu">
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
        </div>
      </div>

      {/* Mobile menu */}
      {isOpen && (
        <div className="sm:hidden">
          <div className="pt-2 pb-3 space-y-1">
            <Link
              to="/"
              className={`block pl-3 pr-4 py-2 border-l-4 text-base font-medium ${
                isActive("/")
                  ? "border-gray-900 dark:border-gray-100 bg-gray-50 dark:bg-gray-900"
                  : "border-transparent hover:bg-gray-50 dark:hover:bg-gray-900"
              }`}
              onClick={closeMenu}
            >
              Home
            </Link>
            <Link
              to="/browse"
              className={`block pl-3 pr-4 py-2 border-l-4 text-base font-medium ${
                isActive("/browse")
                  ? "border-gray-900 dark:border-gray-100 bg-gray-50 dark:bg-gray-900"
                  : "border-transparent hover:bg-gray-50 dark:hover:bg-gray-900"
              }`}
              onClick={closeMenu}
            >
              Browse Services
            </Link>
            {user && (
              <Link
                to="/dashboard"
                className={`block pl-3 pr-4 py-2 border-l-4 text-base font-medium ${
                  isActive("/dashboard")
                    ? "border-gray-900 dark:border-gray-100 bg-gray-50 dark:bg-gray-900"
                    : "border-transparent hover:bg-gray-50 dark:hover:bg-gray-900"
                }`}
                onClick={closeMenu}
              >
                Dashboard
              </Link>
            )}
            {user ? (
              <button
                className="block w-full text-left pl-3 pr-4 py-2 border-l-4 border-transparent text-base font-medium hover:bg-gray-50 dark:hover:bg-gray-900"
                onClick={() => {
                  logout()
                  closeMenu()
                }}
              >
                Sign Out
              </button>
            ) : (
              <>
                <Link
                  to="/login"
                  className="block pl-3 pr-4 py-2 border-l-4 border-transparent text-base font-medium hover:bg-gray-50 dark:hover:bg-gray-900"
                  onClick={closeMenu}
                >
                  Sign In
                </Link>
                <Link
                  to="/register"
                  className="block pl-3 pr-4 py-2 border-l-4 border-transparent text-base font-medium hover:bg-gray-50 dark:hover:bg-gray-900"
                  onClick={closeMenu}
                >
                  Sign Up
                </Link>
              </>
            )}
          </div>
        </div>
      )}
    </nav>
  )
}

export default Navbar
